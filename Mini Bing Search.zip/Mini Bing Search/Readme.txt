Mini Bing Search

Search Bing right from your browser without leaving your current page.

Mini Bing Search is a proof of concept extension. It loads Bing's mobile search page (http://m.bing.com) in a browser action popup.

This extension was developed by Juliana Pe�a (http://julianapena.com).

Code is available under the GPLv2 (http://creativecommons.org/licenses/GPL/2.0/).